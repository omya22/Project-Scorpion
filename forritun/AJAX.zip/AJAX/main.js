var r = new XMLHttpRequest();
r.open("GET", "https://api.themoviedb.org/3/movie/550?api_key=3c2e3323fb6685239c36ee9312c7bcb0", true);
r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  const response = JSON.parse(r.responseText)
  const container = document.createElement("div");
  const image = document.createElement("img");
  const title = document.createElement("h1");
  image.src = "http://image.tmdb.org/t/p/original" + response.backdrop_path
  title.innerHTML = response.original_title;
  container.append(image);
  container.append(title);
  document.body.append(container);
};
r.send("banana=yellow");
